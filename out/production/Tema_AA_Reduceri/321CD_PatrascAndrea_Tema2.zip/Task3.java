import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Task3 extends Task {
  int N, M, K;
  int[][] mat;
  int[][] y;
  int V;
  boolean oracleStatement;
  ArrayList<Integer> encodedVars = new ArrayList<>();

  public Task3() {
    N = 0;
    M = 0;
    K = 0;
    V = 0;
    oracleStatement = false;
  }

  @Override
  public void solve() throws IOException, InterruptedException {
    readProblemData();
    formulateOracleQuestion();
    // askOracle();
    decipherOracleAnswer();
    writeAnswer();
  }

  @Override
  public void readProblemData() throws IOException {
    try {

      InputStreamReader in = new InputStreamReader(System.in);

      BufferedReader input = new BufferedReader(in);

      String str;

      int firstLine = 0;

      while ((str = input.readLine()) != null) {
        String[] splitStr = str.trim().split(" ");
        if (firstLine == 0) {
          N = Integer.parseInt(splitStr[0]);
          M = Integer.parseInt(splitStr[1]);
          K = Integer.parseInt(splitStr[2]);
          firstLine++;

          //// System.out.println("N " + N + " si " + " M " + M);
          mat = new int[N][N];
          y = new int[N][K];

          for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
              mat[i][j] = 0; // intializam mat de adiacenta
            }
          }

          // matricea de clauze / variabile encodate
          int aux = 1;
          for (int i = 0; i < N; i++) {
            for (int j = 0; j < K; j++) {
              y[i][j] = aux; // y[0][0] ~~ y[1][1] -> primul nod = primul element din acoperire
              aux++; // si este codificat cu 1. y[1][2] = 2 (primul nod = al doilea elem din
              // acop)...
            }
          }

          for (int i = 0; i < N; i++) {
            for (int j = 0; j < K; j++) {
              System.out.print(y[i][j] + " ");
            }
            System.out.println();
          }

        } else {
          if (splitStr.length != 1) {

            int i = Integer.parseInt(splitStr[0]);
            int j = Integer.parseInt(splitStr[1]);

            mat[i - 1][j - 1] = 1; // umplem matricea de adiacenta
            mat[j - 1][i - 1] = 1; // in ambele sensuri deoarece lucram pe graf neorientat
          } else {
            break;
          }
        }
      }
    } catch (IOException io) {
      io.printStackTrace();
    }
  }

  @Override
  public void formulateOracleQuestion() throws IOException {
    int V = N * K;
    this.V = V;

    for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) {
        System.out.print(mat[i][j] + " ");
      }
      System.out.println();
    }

    try {
      int nrClauses = 0;
      BufferedWriter writer = new BufferedWriter(new FileWriter("sat.cnf"));
      StringBuilder clauses = new StringBuilder();
      clauses.append("");

      nrClauses = buildFirstClauses(clauses, nrClauses);
      //      nrClauses = buildSecondClauses(clauses, nrClauses);
      //      nrClauses = buildThirdClauses(clauses, nrClauses);
      //      nrClauses = buildFourthClauses(clauses, nrClauses);

      writer.write("p cnf " + V + " " + nrClauses + "\n");
      writer.write(String.valueOf(clauses));
      writer.close();
      System.out.println();
      System.out.println(clauses);
      System.out.println();

      System.out.println("Num of clauses " + nrClauses);
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }

  public int buildFirstClauses(StringBuilder clauses, int nrClauses) {
    for (int i = 0; i < K; i++) {
      for (int j = 0; j < N; j++) {
        clauses.append(y[j][i]).append(" "); // fiecare nod = element posibil al acoperirii
      }
      clauses.append("0\n");
      nrClauses++;
    }
    return nrClauses;
  }

  public int buildSecondClauses(StringBuilder clauses, int nrCLauses) {

    return nrCLauses;
  }

  public int buildThirdClauses(StringBuilder clauses, int nrClauses) {

    return nrClauses;
  }

  public int buildFourthClauses(StringBuilder clauses, int nrClauses) {

    return nrClauses;
  }

  @Override
  public void decipherOracleAnswer() throws IOException {}

  @Override
  public void writeAnswer() throws IOException, InterruptedException {}
}
